import { nanoid } from 'nanoid';
import SessionStore from '../models/sessionStore.js';

export async function generatePairingCode(phoneNumber) {
  // Placeholder: In production, integrate Baileys pairing
  const code = nanoid(6).toUpperCase();
  await SessionStore.saveSession(code, { phoneNumber, createdAt: Date.now() });
  return code;
}

export async function getPairingSession(code) {
  return await SessionStore.getSession(code);
}
