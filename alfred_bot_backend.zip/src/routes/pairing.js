import express from 'express';
import { generatePairingCode, getPairingSession } from '../services/baileysService.js';

const router = express.Router();

router.post('/generate', async (req, res) => {
  try {
    const { phoneNumber } = req.body;
    if (!phoneNumber) {
      return res.status(400).json({ error: 'Phone number is required' });
    }
    const code = await generatePairingCode(phoneNumber);
    return res.json({ code });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to generate pairing code' });
  }
});

router.get('/:code', async (req, res) => {
  try {
    const { code } = req.params;
    const session = await getPairingSession(code);
    if (!session) return res.status(404).json({ error: 'Session not found' });
    return res.json({ session });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch session' });
  }
});

export default router;
