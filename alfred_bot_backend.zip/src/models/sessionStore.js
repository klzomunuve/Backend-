import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';

const adapter = new JSONFile(process.env.DB_FILE || './db.json');
const db = new Low(adapter, { sessions: [] });

await db.read();

class SessionStore {
  static async saveSession(code, data) {
    db.data.sessions.push({ code, ...data });
    await db.write();
  }

  static async getSession(code) {
    return db.data.sessions.find(s => s.code === code);
  }
}

export default SessionStore;
