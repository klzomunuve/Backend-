import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pairingRoutes from './routes/pairing.js';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// Middleware: simple API key check
app.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== process.env.API_KEY) {
    return res.status(403).json({ error: 'Forbidden: Invalid API Key' });
  }
  next();
});

app.use('/api/pair', pairingRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});
