import makeWASocket, { useMultiFileAuthState, makeCacheableSignalKeyStore, fetchLatestBaileysVersion } from '@whiskeysockets/baileys'
import P from 'pino'
import SessionStore from '../models/sessionStore.js'

let clients = {}

export async function generatePairingCode(phoneNumber) {
  const { state, saveCreds } = await useMultiFileAuthState(`./sessions/${phoneNumber}`)
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    logger: P({ level: 'silent' }),
    printQRInTerminal: true,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' })),
    },
    browser: ['AlfredBot', 'Chrome', '1.0.0'],
  })

  sock.ev.on('creds.update', saveCreds)

  let code = null
  if (sock.authState.creds.registered) {
    console.log('✅ Already paired for', phoneNumber)
  } else {
    code = await sock.requestPairingCode(phoneNumber)
    console.log(`🔑 Pairing code for ${phoneNumber}:`, code)
  }

  clients[phoneNumber] = sock
  await SessionStore.saveSession(code, { phoneNumber, createdAt: Date.now() })

  return code
}

export async function getPairingSession(code) {
  return await SessionStore.getSession(code)
}
