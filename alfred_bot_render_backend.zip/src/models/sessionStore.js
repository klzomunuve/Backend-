const sessions = {}

export default class SessionStore {
  static async saveSession(code, data) {
    sessions[code] = data
  }

  static async getSession(code) {
    return sessions[code] || null
  }
}
