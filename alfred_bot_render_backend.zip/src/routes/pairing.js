import express from 'express'
import { generatePairingCode, getPairingSession } from '../services/baileysService.js'

const router = express.Router()

// POST /api/pair/generate
router.post('/generate', async (req, res) => {
  try {
    const { phoneNumber } = req.body
    if (!phoneNumber) return res.status(400).json({ error: 'Phone number required' })

    const code = await generatePairingCode(phoneNumber)
    res.json({ code })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to generate code' })
  }
})

// GET /api/pair/:code
router.get('/:code', async (req, res) => {
  try {
    const session = await getPairingSession(req.params.code)
    if (!session) return res.status(404).json({ error: 'Not found' })
    res.json({ session })
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch session' })
  }
})

export default router
