import express from 'express'
import dotenv from 'dotenv'
import pairingRoutes from './routes/pairing.js'

dotenv.config()

const app = express()
app.use(express.json())

app.use('/api/pair', pairingRoutes)

const PORT = process.env.PORT || 4000
app.listen(PORT, () => {
  console.log(`🚀 Alfred Bot Backend running on port ${PORT}`)
})
